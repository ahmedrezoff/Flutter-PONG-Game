import 'package:flutter/material.dart';
import 'start_screen.dart';
import 'main.dart';

class GameOverScreen extends StatelessWidget
{
  final String result;
  final int score;
  final String playerName;
  final String difficulty;

  const GameOverScreen({
    super.key,
    required this.result,
    required this.score,
    required this.playerName,
    required this.difficulty,
  });

  @override
  Widget build(BuildContext context)
  {
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [DARK_BG, Color(0xFF120017)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                result,
                style: const TextStyle(
                  color: NEON_YELLOW,
                  fontSize: 40,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),

              Text(
                "Player: $playerName",
                style: const TextStyle(color: NEON_YELLOW, fontSize: 20),
              ),

              Text(
                "Difficulty: $difficulty",
                style: const TextStyle(color: NEON_YELLOW, fontSize: 18),
              ),

              const SizedBox(height: 20),

              Text(
                "Score: $score",
                style: const TextStyle(color: NEON_YELLOW, fontSize: 28),
              ),

              const SizedBox(height: 36),

              ElevatedButton(
                onPressed: ()
                {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => const StartScreen()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: NEON_PURPLE,
                  foregroundColor: NEON_YELLOW,
                  padding: const EdgeInsets.symmetric(horizontal: 36, vertical: 14),
                ),
                child: const Text("Return to Menu", style: TextStyle(fontSize: 18)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
