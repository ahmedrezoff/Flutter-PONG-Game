import 'package:cloud_firestore/cloud_firestore.dart';
import 'game_screen.dart';

class FirebaseService
{
  static final FirebaseFirestore _db = FirebaseFirestore.instance;

  static Future<void> saveScore({
    required String player,
    required int score,
    required String difficulty,
  }) async
  {
    await _db.collection("leaderboard").add({
      "player": player,
      "score": score,
      "difficulty": difficulty,
      "time": FieldValue.serverTimestamp(),
    });
  }

  static Stream<QuerySnapshot> getLeaderboard()
  {
    return _db
        .collection("leaderboard")
        .orderBy("score", descending: true)
        .limit(10)
        .snapshots();
  }
}
